import 'dart:io';
import 'package:flutter/material.dart';


class EditProfilePage extends StatefulWidget {

  final String name;
  final String surname;
  final String phone;
  final String email;
  final String role;
  final String language;
  final File? image;

  EditProfilePage({
    required this.name,
    required this.surname,
    required this.phone,
    required this.email,
    required this.role,
    required this.language,
    required this.image,
  });

  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {

  late TextEditingController nameController;
  late TextEditingController surnameController;
  late TextEditingController phoneController;
  late TextEditingController emailController;
  late TextEditingController roleController;
  late TextEditingController languageController;

  

  @override
  void initState() {
    super.initState();

    nameController = TextEditingController(text: widget.name);
    surnameController = TextEditingController(text: widget.surname);
    phoneController = TextEditingController(text: widget.phone);
    emailController = TextEditingController(text: widget.email);
    roleController = TextEditingController(text: widget.role);
    languageController = TextEditingController(text: widget.language);

    
  }

  

  void saveProfile() {

    Navigator.pop(context, {
      "name": nameController.text,
      "surname": surnameController.text,
      "phone": phoneController.text,
      "email": emailController.text,
      "role": roleController.text,
      "language": languageController.text,
      
    });

  }

  Widget buildTextField(String label, TextEditingController controller) {

    return Padding(
      padding: EdgeInsets.all(8),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
        ),
      ),
    );

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: Text("Edit Profile"),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [

            SizedBox(height: 20),

            GestureDetector(
              
              child: CircleAvatar(
                radius: 60,
                
                
              ),
            ),

            SizedBox(height: 20),

            buildTextField("Name", nameController),
            buildTextField("Surname", surnameController),
            buildTextField("Phone", phoneController),
            buildTextField("Email", emailController),
            buildTextField("Role", roleController),
            buildTextField("Language", languageController),

            SizedBox(height: 20),

            ElevatedButton(
              onPressed: saveProfile,
              child: Text("Save"),
            )

          ],
        ),
      ),

    );

  }

}