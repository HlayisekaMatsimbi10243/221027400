import 'dart:io';
import 'package:flutter/material.dart';
import 'edit_profile_page.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {

  File? profileImage;

  String name = "Paballo";
  String surname = "Smith";
  String phone = "0712345678";
  String email = "paballo@email.com";
  String role = "Student";
  String language = "Flutter";

  void updateProfile(Map<String, dynamic> data) {
    setState(() {
      name = data['name'];
      surname = data['surname'];
      phone = data['phone'];
      email = data['email'];
      role = data['role'];
      language = data['language'];
      profileImage = data['image'];
    });
  }

  Widget buildInfo(String title, String value) {
    return ListTile(
      title: Text(title),
      subtitle: Text(value),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Profile Page"),
        centerTitle: true,
      ),

      body: Column(
        children: [

          SizedBox(height: 20),

          CircleAvatar(
            radius: 60,
            backgroundImage:
                profileImage != null ? FileImage(profileImage!) : null,
            child: profileImage == null
                ? Icon(Icons.person, size: 60)
                : null,
          ),

          SizedBox(height: 20),

          buildInfo("Name", name),
          buildInfo("Surname", surname),
          buildInfo("Phone", phone),
          buildInfo("Email", email),
          buildInfo("Role", role),
          buildInfo("Language", language),

          SizedBox(height: 20),

          ElevatedButton(
            onPressed: () async {

              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => EditProfilePage(
                    name: name,
                    surname: surname,
                    phone: phone,
                    email: email,
                    role: role,
                    language: language,
                    image: profileImage,
                  ),
                ),
              );

              if (result != null) {
                updateProfile(result);
              }

            },
            child: Text("Edit Profile"),
          )

        ],
      ),
    );
  }
}