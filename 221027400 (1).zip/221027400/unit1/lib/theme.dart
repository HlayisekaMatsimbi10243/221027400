import 'package:flutter/material.dart';

class AppColors {

  static const Color purpleDark = Color(0xFF6A1B9A);
  static const Color purple = Color(0xFF9C27B0);
  static const Color purpleLight = Color(0xFFCE93D8);

  static const Color pinkDark = Color(0xFFC2185B);
  static const Color pink = Color(0xFFE91E63);
  static const Color pinkLight = Color(0xFFF8BBD0);

}

LinearGradient mainGradient = LinearGradient(
  colors: [
    AppColors.purpleDark,
    AppColors.purple,
    AppColors.pink
  ],
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
);

LinearGradient buttonGradient = LinearGradient(
  colors: [
    AppColors.pink,
    AppColors.purple
  ],
);